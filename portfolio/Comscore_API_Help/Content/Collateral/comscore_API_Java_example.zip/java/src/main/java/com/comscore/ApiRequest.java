package com.comscore;

public class ApiRequest {
    private String endpoint;
    private String json;

    ApiRequest(String endpoint, String json) {
        this.endpoint = endpoint;
        this.json = json;
    }

    String getEndpoint() {
        return endpoint;
    }

    String getJson() {
        return json;
    }
}
