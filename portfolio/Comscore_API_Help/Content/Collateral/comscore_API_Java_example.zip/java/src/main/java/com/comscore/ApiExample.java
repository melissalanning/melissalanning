package com.comscore;

public class ApiExample {
    // to compile and run:
    // mvn exec:java
    public static void main(String[] args) {
        try {
            String url = "https://api.rentrak.com";
            String clientId = "<client_id>";
            String clientSecret = "<client_secret>";
            Integer timeoutSec = 1200;
            Integer openTimeoutSec = 30;

            String div = new String(new char[80]).replace("\0", "=");
            ApiClient api = new ApiClient(url, clientId, clientSecret, timeoutSec, openTimeoutSec);

            System.out.println("comScore TV API Examples");
            System.out.println(div);

            System.out.println("Metadata endpoint call");
            api.makePollingRequest(metadataApiRequest).forEach(ApiResponse::dump);

            System.out.println(div);
            System.out.println("Local Airings endpoint call");
            api.makePollingRequest(localAiringsApiRequest).forEach(ApiResponse::dump);

            System.out.println(div);
            System.out.println("National Airings endpoint call");
            api.makePollingRequest(nationalAiringsApiRequest).forEach(ApiResponse::dump);

            System.out.println(div);
            System.out.println("Multipage call");
            api.makePollingRequest(multipageApiRequest).forEach(ApiResponse::dump);
            System.out.println(div);

            System.exit(0);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    private static ApiRequest metadataApiRequest = new ApiRequest(
            "/tv/v4/metadata/markets",
            "{" +
                    "    \"fields\": [\n" +
                    "      \"market_no\",\n" +
                    "      \"market_name\"\n" +
                    "    ]\n" +
                    "}"
    );

    private static ApiRequest localAiringsApiRequest = new ApiRequest(
            "/tv/v4/local_airing_views",
            "{\n" +
                    "    \"fields\": [\n" +
                    "      \"day\",\n" +
                    "      \"market_name\",\n" +
                    "      \"network_name\",\n" +
                    "      \"station_call_sign\",\n" +
                    "      \"series_name\",\n" +
                    "      \"rating\",\n" +
                    "      {\n" +
                    "        \"demo_no\": 2453,\n" +
                    "        \"field\": \"demo_index\"\n" +
                    "      }\n" +
                    "    ],\n" +
                    "    \"filters\": [\n" +
                    "      [\n" +
                    "        \"eq\",\n" +
                    "        \"day\",\n" +
                    "        \"2014-09-18\"\n" +
                    "      ],\n" +
                    "      [\n" +
                    "        \"eq\",\n" +
                    "        \"market_no\",\n" +
                    "        820\n" +
                    "      ],\n" +
                    "      [\n" +
                    "        \"eq\",\n" +
                    "        \"station_no\",\n" +
                    "        4653\n" +
                    "      ]\n" +
                    "    ],\n" +
                    "    \"group_by\": [\n" +
                    "      \"market_no\",\n" +
                    "      \"network_no\",\n" +
                    "      \"station_no\",\n" +
                    "      \"series_no\",\n" +
                    "      \"day\"\n" +
                    "    ],\n" +
                    "    \"start_of_day\": \"07:00\"\n" +
                    "  }");

    private static ApiRequest nationalAiringsApiRequest = new ApiRequest(
            "/tv/v4/national_airing_views",
            "{\n" +
                    "    \"fields\": [\n" +
                    "      \"network_name\",\n" +
                    "      \"rating\"\n" +
                    "    ],\n" +
                    "    \"filters\": [\n" +
                    "      [\n" +
                    "        \"eq\",\n" +
                    "        \"day\",\n" +
                    "        \"2015-05-30\"\n" +
                    "      ],\n" +
                    "      [\n" +
                    "        \"in\",\n" +
                    "        \"network_no\",\n" +
                    "        3,\n" +
                    "        4,\n" +
                    "        5,\n" +
                    "        6\n" +
                    "      ],\n" +
                    "      [\n" +
                    "        \"eq\",\n" +
                    "        \"qtr_hour_start_time\",\n" +
                    "        \"20:00\"\n" +
                    "      ]\n" +
                    "    ],\n" +
                    "    \"group_by\": [\n" +
                    "      \"network_no\"\n" +
                    "    ]\n" +
                    "  }"
    );

    private static ApiRequest multipageApiRequest = new ApiRequest(
            "/tv/v4/metadata/networks",
            "{" +
                    "\"filters\": [\n" +
                    "  [\n" +
                    "    \"in\",\n" +
                    "    \"network_no\",\n" +
                    "    10753, 10741, 10737, 10735, 11074,\n" +
                    "    12370, 12368, 12372, 12374, 12376,\n" +
                    "    3, 4, 5\n" +
                    "  ]\n" +
                    "],\n" +
                    "\"page_size\": 5" +
                    "}"
    );
}
