package com.comscore;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Optional;

class ApiResponse {
    private String responseJson;
    private String apiVersion;
    private JSONObject json;

    ApiResponse(String responseJson, String apiVersion) {
        this.responseJson = responseJson;
        this.apiVersion = apiVersion;

        try {
            this.json = new JSONObject(responseJson);
        }
        catch (JSONException ex) {
            // Failed to parse JSON
            this.json = new JSONObject().put("exception", ex.toString());
        }
    }

    String getJson() {
        return responseJson;
    }

    String getApiVersion() {
        return apiVersion;
    }

    String getStatus() {
        return json.optString("status", "unknown");
    }

    Optional<String> getNextPageRequest() {
        String nextPageToken = json.optString("next_page_token");

        if (nextPageToken != null && !nextPageToken.isEmpty()) {
            JSONObject jsonElements = new JSONObject();
            jsonElements.put("token", nextPageToken);
            jsonElements.put("timeout", new Integer(120 * 1000));

            return Optional.of(jsonElements.toString());
        }
        else {
            return Optional.empty();
        }
    }

    void dump() {
        System.out.println(json.toString(4));
    }
}
