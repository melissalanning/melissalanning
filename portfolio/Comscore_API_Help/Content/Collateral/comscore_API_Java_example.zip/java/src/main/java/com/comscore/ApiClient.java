package com.comscore;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;

import java.util.Date;
import java.util.TimeZone;

class ApiClient {
    private String baseUrl;
    private String clientId;
    private String clientSecret;
    private int timeoutSec;
    private int openTimeoutSec;
    private SimpleDateFormat dateFormat;
    private static Charset utf8Charset = Charset.forName("UTF-8");

    ApiClient(String baseUrl, String clientId, String clientSecret, int timeoutSec, int openTimeoutSec) {
        this.baseUrl = baseUrl;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.timeoutSec = timeoutSec;
        this.openTimeoutSec = openTimeoutSec;

        this.dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
        this.dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    }

    List<ApiResponse> makePollingRequest(ApiRequest apiRequest) throws ApiException {
        String nextPageEndpointPath = "/tv/v4/retrieve_dataset";
        return makePollingRequest(apiRequest, nextPageEndpointPath);
    }

    List<ApiResponse> makePollingRequest(ApiRequest apiRequest, String nextPageEndpointPath) throws ApiException {
        ApiResponse apiResponse = makeRequest(apiRequest);
        Optional<String> optNextPageRequest = apiResponse.getNextPageRequest();
        List<ApiResponse> allResponses = new ArrayList<ApiResponse>();
        allResponses.add(apiResponse);

        while (optNextPageRequest.isPresent()) {
            apiResponse = makeRequest(new ApiRequest(nextPageEndpointPath, optNextPageRequest.get()));
            allResponses.add(apiResponse);
            optNextPageRequest = apiResponse.getNextPageRequest();
        }

        return allResponses;
    }

    private ApiResponse makeRequest(ApiRequest apiRequest) throws ApiException {

        ApiResponse response = null;

        try {
            String fullUrl = baseUrl + apiRequest.getEndpoint();
            String timestamp = getCurrentTimestamp();
            String signature = generateSignature(clientSecret, apiRequest.getEndpoint(), timestamp, apiRequest.getJson());

            RequestConfig.Builder requestBuilder =
                    RequestConfig.custom()
                            .setSocketTimeout(timeoutSec * 1000)
                            .setConnectTimeout(openTimeoutSec * 1000)
                            .setConnectionRequestTimeout(openTimeoutSec * 1000);

            HttpClientBuilder builder = HttpClientBuilder.create();
            builder.setDefaultRequestConfig(requestBuilder.build());
            HttpClient client = builder.build();
            HttpPost post = createRequest(fullUrl, signature, timestamp, apiRequest.getJson());

            HttpResponse httpResponse = client.execute(post);

            BufferedReader br = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));
            StringBuilder content = new StringBuilder();
            String line;

            while (null != (line = br.readLine())) {
                content.append(line);
            }

            String apiVersion = httpResponse.getFirstHeader("api-version").getValue();
            String responseJson = "{}";

            if (httpResponse.getFirstHeader("content-type").getValue().equals("text/plain; charset=UTF-8")) {
                responseJson =
                        new JSONObject()
                            .put("api_version", "<unknown>")
                            .put("message", content.toString())
                            .put("code", httpResponse.getStatusLine().getStatusCode())
                            .put("status", "http_error")
                            .put("http_status", httpResponse.getStatusLine().getStatusCode())
                            .toString();
            }
            else {
                responseJson = content.toString();
            }

            response = new ApiResponse(responseJson, apiVersion);
        }
        catch( Exception ex) {
            throw new ApiException("Failed to process comScore API request", ex);
        }

        return response;
    }

    private HttpPost createRequest(String fullUrl, String rtkSignature, String timestamp, String requestJson) throws IOException {
        HttpPost post = new HttpPost(fullUrl);

        post.setHeader("Date", timestamp);
        post.setHeader("Authorization", "RTK " + clientId + ":" + rtkSignature);

        StringEntity json = new StringEntity(requestJson);
        json.setContentType("application/json");
        post.setEntity(json);

        return post;
    }

    private static String generateSignature(String clientSecret, String endpointPath, String timestamp, String request)
            throws NoSuchAlgorithmException, InvalidKeyException, IllegalStateException, UnsupportedEncodingException {
        String stringToSign = String.join("\n", new String[] { endpointPath, timestamp, request });

        Mac mac = Mac.getInstance("HmacSHA1");
        SecretKeySpec secretKeySpec = new SecretKeySpec(clientSecret.getBytes(utf8Charset), "HmacSHA1");
        mac.init(secretKeySpec);

        byte[] digest = mac.doFinal(stringToSign.getBytes(utf8Charset));
        byte[] encodedBytes = Base64.encodeBase64(digest);

        return new String(encodedBytes);
    }

    private String getCurrentTimestamp() {
        final Date currentTime = new Date();
        return dateFormat.format(currentTime);
    }
}
