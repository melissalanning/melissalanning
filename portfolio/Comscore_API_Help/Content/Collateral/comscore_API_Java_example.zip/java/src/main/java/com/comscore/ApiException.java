package com.comscore;

class ApiException extends Exception {
    ApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
