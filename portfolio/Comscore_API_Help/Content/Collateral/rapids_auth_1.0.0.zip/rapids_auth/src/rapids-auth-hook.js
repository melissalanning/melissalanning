const CryptoJS = require("crypto-js");
const utf8     = require('crypto-js/enc-utf8');

module.exports = function(context) {

  const request = context.request;

  const uuid   = request.getEnvironmentVariable("CLIENT_ID");
  const secret = request.getEnvironmentVariable("CLIENT_SECRET");

  if(uuid === undefined || secret === undefined) {
    return;
  }

  if(request.hasHeader('Authorization')) {
    const header = request.getHeader('Authorization')
    console.log(`[rapids-auth] Authorization header already use: ${JSON.stringify(header)}`);
    return;
  }

  const xDate = (new Date()).toUTCString();

  const url = document.createElement('a');
  url.href  = request.getUrl();
  const path = url.pathname + url.search;

  const body = request.getBodyText();

  const stringToSign = path + "\n" + xDate + "\n" + body;

  const encodedSecret = utf8.parse(secret);
  const encodedStringToSign = utf8.parse(stringToSign);

  const sha1_hash = CryptoJS.HmacSHA1(encodedStringToSign, encodedSecret);
  console.log(`[rapids-auth] SHA1: ${sha1_hash}`)

  const signature = CryptoJS.enc.Base64.stringify(sha1_hash)

  const authToken    = "RTK " + uuid + ":" + signature;

  console.log(`[rapids-auth] Injecting date header X-Date: ${xDate}`);
  console.log(`[rapids-auth] Injecting auth header Authorization: ${authToken}`);

  context.request.setHeader('Date', xDate);
  context.request.setHeader('Authorization', authToken);

};
