# Linear Rapids Authentication Plugin

This plugin enables HmacSHA1 based authentication to requests in [Insomnia REST Client](https://insomnia.rest/).

## Install

The installation path will change depending on your systems OS
```
MacOS: ~/Library/Application\ Support/Insomnia/plugins/
Windows: %APPDATA%\Insomnia\plugins\
Linux: $XDG_CONFIG_HOME/Insomnia/plugins/ or ~/.config/Insomnia/plugins/
```

```
mkdir -p $HOME/<OS_INSTALL_PATH>
cd $HOME/<OS_INSTALL_PATH>
ln -s <linear-api-utils repo location>/scripts/rapids_auth .
cd rapids_auth
npm install
```

## Installation (Package)

Inside the Insomnia REST client plugin manager, simply refresh the available plugins.

## Usage

In the Insomnia REST client, create an environment and add these variables:
```
{
  "CLIENT_ID": "<your-client-id>",
  "CLIENT_SECRET": "<your-client-secret>"
}
```

Once these are defined, the plugin will add the following headers automatically to every request:

```
Date: Wed, 16 Jan 2019 15:26:07 GMT
Authorization: RTK <client-id>:<generated-signature>
```
