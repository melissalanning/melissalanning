module.exports.requestHooks = [
  require('./src/rapids-auth-hook')
];
