#!/usr/bin/env python

import json
from api_client import ApiClient


def api_call_example():
    api = ApiClient(
        url='https://api.rentrak.com',
        client_id='your client id here',
        client_secret='your secret here',
        timeout_sec=1200,
        open_timeout_sec=30
    )

    endpoint_path = '/tv/v3/national_airing_views'
    api_request = json.loads("""{
        "fields": [
            "network_name",
            "rating"
        ],
        "filters": [
            [
                "eq",
                "day",
                "2014-05-30"
            ],
            [
                "in",
                "network_no",
                3,
                4,
                5,
                6
            ],
            [
                "eq",
                "qtr_hour_start_time",
                "20:00"
            ]
        ],
        "group_by": [
            "network_no"
        ]
    }""")

    # Make a request to API and wait for all response pages
    (api_version, api_response) = api.make_polling_request(endpoint_path, api_request)

    # Pretty print the response
    print(json.dumps(api_response, indent=2))

    return 0

if __name__ == '__main__':
    api_call_example()
