To send the actual request one needs to edit api_example.py. In particular insert the real client_id and client_secret in there:
    api = ApiClient(
        url='https://api.rentrak.com',
        client_id='your client id here',
        client_secret='your secret here',
        timeout_sec=1200,
        open_timeout_sec=30
    )
 
Also, the endpoint path and the request json need to be pasted there as well:
    endpoint_path = '/tv/v3/national_airing_views'
    api_request = json.loads("""{
        "fields": [
            "network_name",
            "rating"
        ],
        "filters": [
            [
                "eq",
                "day",
                "2014-05-30"
            ],
            [
                "in",
                "network_no",
                3,
                4,
                5,
                6
            ],
            [
                "eq",
                "qtr_hour_start_time",
                "20:00"
            ]
        ],
        "group_by": [
            "network_no"
        ]
    }""")

To run the example, execute the following command from the dir where the py files are extracted:
 
python ./api_example.py
