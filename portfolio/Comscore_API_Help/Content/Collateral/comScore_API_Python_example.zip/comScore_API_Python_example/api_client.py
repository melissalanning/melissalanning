import hmac
import json
from base64 import b64encode
from datetime import datetime
from hashlib import sha1
from string import hexdigits

import requests


class ApiException(Exception):
    pass


class ApiClient:
    def __init__(self, url, client_id, client_secret, timeout_sec, open_timeout_sec, access_token=None):
        self.base_url = url
        self.timeout_sec = max(int(timeout_sec), 1)
        self.open_timeout_sec = max(int(open_timeout_sec), 1)

        if client_id is not None:
            # Client Id has a preference over access token
            self.client_id = client_id
            self.client_secret = client_secret
            self.access_token = None

            if self.client_id is None or self.client_secret is None:
                raise ApiException('Need access_token or client_id and client_secret')
        else:
            self.client_id = None
            self.client_secret = None
            self.access_token = access_token

    @staticmethod
    def generate_signature(client_secret, endpoint_path, timestamp, request):
        string_to_sign = "\n".join((endpoint_path, timestamp, json.dumps(request)))
        sha1_hash = hmac.new(client_secret.encode('utf-8'), string_to_sign.encode('utf-8'), sha1)
        return b64encode(sha1_hash.digest()).decode('utf-8')

    def generate_headers(self, endpoint_path, request):

        timestamp = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')

        if self.client_id is None:
            if self.access_token is not None:
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer %s' % self.access_token,
                    'Date': timestamp
                }
            else:
                raise ApiException("Either client_id or token must be specified")
        else:
            assert self.client_secret, "Client secret must be defined"

            signature = self.generate_signature(
                    self.client_secret,
                    endpoint_path,
                    timestamp,
                    request)

            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'RTK %s:%s' % (self.client_id, signature),
                'Date': timestamp
            }
        return headers

    def api_version(self, env):
        try:
            # The endpoint will return 404, but that's ok as the header still contains the api-version
            response = requests.post(self.base_url + "/tv/v2",
                                     timeout=(self.open_timeout_sec, self.timeout_sec))
        except requests.exceptions.Timeout as ex:
            raise ApiException("Timeout while connecting to '%s' environment : %s" % (env, ex.args[0]))
        except requests.exceptions.ConnectionError as ex:
            raise ApiException("Cannot connect to '%s' environment : %s" % (env, ex.args[0]))

        return response.headers['api-version'] if 'api-version' in response.headers else None

    def make_request(self,
                     endpoint_path,
                     request):

        url = self.base_url + endpoint_path

        headers = self.generate_headers(
            endpoint_path,
            request
        )

        try:
            response = requests.post(
                url,
                data=json.dumps(request),
                headers=headers,
                timeout=(self.open_timeout_sec, self.timeout_sec)
            )
        except requests.exceptions.Timeout as t:
            raise ApiException(t)

        # We can expect receiving JSON response with these status codes
        expected_status_codes = {200,  # OK
                                 400,  # Bad Request
                                 403,  # Forbidden
                                 404,  # Not Found
                                 408,  # Request Timeout
                                 429,  # Too many requests
                                 500,  # Internal Server Error
                                 503   # Service Unavailable
                                 }

        if response.status_code not in expected_status_codes:
            raise ApiException("Unexpected response code from API: %s %s" % (response.status_code, response.text))

        if 'content-type' not in response.headers:
            raise ApiException("Unexpected Content-Type header from API: %s" %
                               response.headers.get('content-type', '<missing>'))

        if response.headers['content-type'] == 'text/plain; charset=UTF-8':
            json_body = {
                'message': '%s (%i)' % (response.text, response.status_code),
                'code': response.status_code,
                'status': 'http_error'
            }

        elif response.headers['content-type'] == 'application/json; charset=UTF-8':
            json_body = response.json()
        else:
            raise ApiException("Unexpected Content-Type header from API: %s" %
                               response.headers.get('content-type', '<missing>'))

        if response.status_code != 500:
            if 'api-version' not in response.headers:
                raise ApiException("Missing Api-Version header in the API response")

            elif (len(response.headers['api-version']) <= 0 or
                    not all(c in hexdigits for c in response.headers['api-version'])):

                raise ApiException("Unexpected Api-Version header from API: %s" % response.headers['api-version'])

            elif ('access-control-allow-origin' not in response.headers) \
                    or (response.headers['access-control-allow-origin'] != '*'):

                raise ApiException("Unexpected Access-Control-Allow-Origin header from API: %s"
                                   % response.headers['access-control-allow-origin'])

            elif ('access-control-allow-headers' not in response.headers) \
                    or (response.headers['access-control-allow-headers'] != 'Content-Type, Authorization'):

                raise ApiException("Unexpected Access-Control-Allow-Headers header from API: %s"
                                   % response.headers['access-control-allow-headers'])
            else:
                # assume response is json
                return response.headers['api-version'], json_body
        else:
            return None, json_body

    @staticmethod
    def next_page_request(response):
        if response and response.get('next_page_token'):
            retrieve_request = {
                'token': response['next_page_token'],
                'timeout': 120
            }
        else:
            retrieve_request = None
        return retrieve_request

    def make_polling_request(self,
                             endpoint_path,
                             request):
        (api_version, response) = self.make_request(
                endpoint_path,
                request
        )

        while response.get('status', 'unknown') == 'processing':
            (api_version, response) = self.make_request(
                    '/tv/v2/retrieve_dataset',
                    ApiClient.next_page_request(response)
            )

        return api_version, response
