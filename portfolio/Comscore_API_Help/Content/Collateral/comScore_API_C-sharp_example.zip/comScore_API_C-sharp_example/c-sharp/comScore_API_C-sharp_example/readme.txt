1. Extract the files from the archive to a folder, and put your .json files in the same folder.

2. Set your clientId and clientSecret keys in the comScoreApi.exe.config file.

<add key="clientId" value="<your client id here" />
<add key="clientSecret" value="<your client secret here" />

3.  From the DOS command line, enter comScoreApi.exe followed by the name of the json request.  Below is an example.
 
comScoreApi.exe NationalAiringsStreamsTest.json
