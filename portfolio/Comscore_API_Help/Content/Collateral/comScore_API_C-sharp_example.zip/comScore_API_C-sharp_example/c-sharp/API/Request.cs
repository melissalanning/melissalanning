﻿using System;
using Newtonsoft.Json.Linq;

namespace comScore
{
	class Request
	{
		public String RawRequest { get; }
		public String Endpoint { get; }
		public Int32  PageNo { get; }
		public String EndpointVersion { get; }

		public Request(String jsonRequest, int pageNo = 0)
		{
			dynamic json = JObject.Parse(jsonRequest);

			Endpoint = json.endpoint_path.ToString();

			if (json.request == null) 
			{
				throw 
				new ApiException ("Mandatory 'request' element is missing from the file", null);
			}

			RawRequest = json.request.ToString();
			PageNo = pageNo;

			var parts = Endpoint.Split (new char[] {'/'}, 4);

			if (parts.Length < 3) 
			{
				throw new ApiException ("Invalid endpoint : " + Endpoint, null);
			}

			EndpointVersion = parts [2]; 
		}
	}
}

