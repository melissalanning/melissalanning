﻿using System;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace comScore
{
	class Api
	{
		#region Properties

		public Uri BaseUrl { get; }
		public int TimeoutSec { get; }
		public String ClientId { get; }
		public String ClientSecret { get; }

		#endregion

		public Api(Uri baseUrl, String clientId, String clientSecret, int timeoutSec) 
		{
			BaseUrl = baseUrl;
			TimeoutSec = Math.Max(timeoutSec, 1);
			ClientId = clientId;
			ClientSecret = clientSecret;
		}

		private static String generateTimestamp()
		{
			return DateTime.UtcNow.ToString (@"ddd, dd MMM yyyy HH:mm:ss G\MT");
		}

		private String generateSignature(String endpointPath, String timestamp, String request)
		{
			Encoding enc = new UTF8Encoding(encoderShouldEmitUTF8Identifier: true, throwOnInvalidBytes: true);
			String stringToSign = String.Join("\n", new string[]{ endpointPath, timestamp, request });

			var hmac = new HMACSHA1(enc.GetBytes(ClientSecret));
			hmac.Initialize();

			return Convert.ToBase64String(hmac.ComputeHash(enc.GetBytes(stringToSign)));
		}

		private Response handleWebException(WebException ex, String endpointVersion, Int32 pageNo)
		{
			Response response = null;

			if (ex.Status == WebExceptionStatus.ProtocolError)
			{
				var httpResponse = ex.Response as HttpWebResponse;
				if (httpResponse != null)
				{
					if(	httpResponse.StatusCode == HttpStatusCode.OK ||
						httpResponse.StatusCode == HttpStatusCode.BadRequest||
						httpResponse.StatusCode == HttpStatusCode.Forbidden ||
						httpResponse.StatusCode == HttpStatusCode.RequestTimeout) 
					{
						if (ex.Response != null) 
						{
							var isJson = httpResponse.ContentType == "application/json; charset=UTF-8";
							var rawData = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
							response = new Response(rawData, isJson, endpointVersion, pageNo);
						}
					}
				}
			}

			if (response == null) 
			{
				throw new ApiException("Unexpected response from comScore API", ex);
			}

			return response;
		}

		public Response process(Request request)
		{
			Response response = null;

			try 
			{
				HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(BaseUrl, request.Endpoint));

				httpRequest.Method = "POST";
				httpRequest.ContentType = "application/json";
				httpRequest.Date = DateTime.UtcNow;
				httpRequest.Timeout = TimeoutSec * 1000;
				httpRequest.ReadWriteTimeout = TimeoutSec * 1000;

				String timestamp = generateTimestamp();
				String signature = generateSignature(request.Endpoint, timestamp, request.RawRequest);
				Byte[] encodedRequest = Encoding.UTF8.GetBytes(request.RawRequest);

				httpRequest.Headers[HttpRequestHeader.Authorization] = String.Format("RTK {0}:{1}", ClientId, signature);
				httpRequest.ContentLength = encodedRequest.Length;

				using (var stream = httpRequest.GetRequestStream())
				{
					stream.Write(encodedRequest, 0, encodedRequest.Length);
				}

				var httpResponse = (HttpWebResponse)httpRequest.GetResponse();

				if(httpResponse.ContentType != "application/json; charset=UTF-8")
				{
					throw new ApiException("Unexpected content type: " + httpResponse.ContentType, null);
				}

				var rawData = new StreamReader(httpResponse.GetResponseStream()).ReadToEnd();
				response = new Response(rawData, true, request.EndpointVersion, request.PageNo);
			}
			catch(WebException ex)
			{
				response = handleWebException(ex, request.EndpointVersion, request.PageNo);
			}

			return response;
		}

		private static String RetriveDatasetEndpoint = "/tv/v3/retrieve_dataset";

		private static Request waitForDataRequest(Response response)
		{
			return new Request(
				String.Format(
					@"
					{{
						'endpoint_path': '{0}',
						'request': {{
							'token': '{1}',
							'timeout': 120 
						}}
					}}

					", RetriveDatasetEndpoint, response.NextPageToken
				),
				response.PageNo
			);
		}

		public static Request nextPageRequest(Response response)
		{
			if (response.Status == "success" && response.NextPageToken != null) {
				return new Request (
					String.Format (
						@"
						{{
							'endpoint_path': '{0}',
							'request': {{
								'token': '{1}',
								'timeout': 120 
							}}
						}}", RetriveDatasetEndpoint, response.NextPageToken
					),
					response.PageNo + 1
				);
			} 
			else 
			{
				return null;
			}
		}

		public Response retrievePage(Request request)
		{
			var response = process(request);

			while (response.StillProcessing && response.NextPageToken != null) 
			{
				response = process(Api.waitForDataRequest(response));
			}

			return response;
		}
	}
}

