﻿using System;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace comScore
{
	struct Warning
	{
		public Warning(Int32 code, String message)
		{
			this.code = code;
			this.message = message;
		}

		public Int32 code;
		public String message;
	}

	class Response
	{
		public String  	RawResponse { get; }
		public String  	Status { get; }
		public String  	RequestId { get; }
		public String 	NextPageToken { get; }
		public Warning[] Warnings { get; }
		public String[] Disclosures { get; }
		public TimeSpan ApiTime { get; }
		public DateTime? FinalDate { get; }
		public Boolean	StillProcessing { get; }
		public Int32  	PageNo { get; }
		public String 	EndpointVersion { get; }
		public Boolean  IsJson { get; }

		public Response(String rawResponse, Boolean isJson, String endpointVersion, int pageNo)
		{
			IsJson = isJson;
			RawResponse = rawResponse;
			EndpointVersion = endpointVersion;
			PageNo = pageNo;

			if (isJson) {
				dynamic json = JObject.Parse (rawResponse);

				Status = json.status;
				RequestId = json.api_request_id;
				NextPageToken = json.next_page_token;

				if (endpointVersion == "v1" || endpointVersion == "v2") 
				{
					String[] warnings = json.warnings != null ? json.warnings.ToObject<string[]> () : new string[0];
					Warnings = warnings.Select (w => new Warning (code: 0, message: w)).ToArray ();
				} 
				else 
				{
					Warnings = json.warnings != null ? json.warnings.ToObject<Warning[]> () : new Warning[0];
				}

				Disclosures = json.disclosures != null ? json.disclosures.ToObject<string[]> () : new string[0];
				ApiTime = json.api_time != null ? TimeSpan.FromMilliseconds (Convert.ToDouble (json.api_time)) : null;
				FinalDate = json.final_date != null ? DateTime.Parse (json.final_date.ToString ()) : null;
			} 
			else 
			{
				Status = "error";
			}

			StillProcessing = Status == "processing";
		}
	}
}

