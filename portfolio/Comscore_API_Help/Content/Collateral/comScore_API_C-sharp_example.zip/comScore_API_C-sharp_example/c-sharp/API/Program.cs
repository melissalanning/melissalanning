﻿using System;
using System.IO;
using System.Configuration;

namespace comScore
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			var jsonRequestFile = args [0];
			var settings = ConfigurationManager.AppSettings;
			Api api = new Api(
								baseUrl: new Uri(settings ["baseUrl"].ToString ()), 
				                clientId: settings ["clientId"].ToString (), 
				                clientSecret: settings ["clientSecret"].ToString (), 
				                timeoutSec: Convert.ToInt32 (settings ["timeoutSec"])
				            );

			try
			{
				Console.WriteLine ("Processing " + jsonRequestFile);
				var request = new Request(File.ReadAllText(jsonRequestFile));
				Response response = null;

				do
				{
					response = api.retrievePage(request);
					Console.WriteLine (response.RawResponse);
					request = Api.nextPageRequest(response);
				}
				while(request != null);

				Console.WriteLine (String.Format("SUCCESS {0}: pages = {1}", jsonRequestFile, (response.PageNo + 1)));
			}
			catch(Exception ex) 
			{
				string message = string.Empty;

				do
				{
					message = message + (message.Length == 0 ? "" : ". ") +  (string.IsNullOrEmpty(ex.Message) ? string.Empty : ex.Message);
					ex = ex.InnerException;
				}
				while (ex != null);

				Console.WriteLine(String.Format("FAILED {0}: {1}", jsonRequestFile, message));
			}
		}
	}
}
